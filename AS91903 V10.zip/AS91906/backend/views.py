from django.core.exceptions import ValidationError
from django.contrib.auth.hashers import make_password, check_password
from django.shortcuts import redirect, render, get_object_or_404
from .models import Book, Student, Record
from django.contrib.auth.decorators import login_required
# Create your views here.

# def isauthenticated(func: callable) -> callable:
     #def wrapper(request, *args, **kwargs):
         #if request.user.is_authenticated:
            # return func(request, *args, **kwargs)
        # return redirect("login")
    # return wrapper

def home(request):
    books = Book.objects.all()
    return render(request, "home.html", {'books': books})

def Register(request):

    if request.method == "POST":

        first_name = request.POST.get("first_name")
        last_name = request.POST.get("last_name")
        email = request.POST.get("email")
        password = request.POST.get("password")
        confirm_password = request.POST.get("confirm_password")


        # Check passwords match
        if password != confirm_password:
            return render(request, "register.html", {
                "errors": {
                    "password": ["Passwords do not match."]
                },
                "first_name": first_name,
                "last_name": last_name,
                "email": email,
            })
        student = Student(
            first_name=first_name,
            last_name=last_name,
            email=email,
            password=make_password(password)
        )
        try:
            # Runs your model clean() validation
            student.clean()

            # Saves into Student table
            student.save()

            # Go to login page after success
            return redirect("login")

        except ValidationError as e:

            return render(request, "register.html", {
                "errors" : {
                     "error" : e.messages
                },
                "first_name": first_name,
                "last_name": last_name,
                "email": email,
            })

    return render(request, "register.html")

def login(request):

    if request.method == "POST":
        email = request.POST.get("email")
        password = request.POST.get("password")
        try:
            # Search Student table using email
            student = Student.objects.get(email=email)
            # Check password against stored hashed password
            if check_password(password, student.password):
                # Store logged-in student details in session
                request.session['student_id'] = student.student_id
                request.session['first_name'] = student.first_name
                # Login successful
                return redirect("home")
            else:
                # Wrong password
                return render(request, "login.html", {
                    "error": "Incorrect password. Please try again."
                })
        except Student.DoesNotExist:
            # Email does not exist
            return render(request, "login.html", {
                "error": "Email is not registered."
            })
    return render(request, "login.html")

@login_required(login_url='/login/')
def books(request, Book_ID):
    book = get_object_or_404(Book, book_id=Book_ID)

    try:        
        Record.objects.get(book=book, user=request.user).delete()
    except:
        pass

    Record(book=book, user=request.user).save()
    return render(request, 'books.html', {'books': books})