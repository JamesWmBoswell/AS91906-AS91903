from django.urls import path
from django.shortcuts import render
from . import views

urlpatterns = [
    path("", views.home, name="home"), 
    path("books/", views.books, name="books"),
    path("signup/", views.Register, name="register"),
    path("login/", views.login, name="login"),
    path('borrow/<int:item_id>/', views.books, name='borrow_item'),
    path('', lambda request: render(request, 'home.html'), name='home'), 
]