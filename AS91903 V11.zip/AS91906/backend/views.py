from django.core.exceptions import ValidationError
from django.contrib.auth.hashers import make_password, check_password
from django.shortcuts import redirect, render, get_object_or_404
from django.contrib import messages
from .models import Book, Student, Record
from django.contrib.auth.decorators import login_required


def home(request):
    books = Book.objects.all()
    return render(request, "home.html", {"books": books})


def Register(request):
    if request.method == "POST":
        first_name = request.POST.get("first_name", "").strip()
        last_name = request.POST.get("last_name", "").strip()
        email = request.POST.get("email", "").strip()
        password = request.POST.get("password", "")
        confirm_password = request.POST.get("confirm_password", "")

        # Check whether the email is already registered
        if Student.objects.filter(email__iexact=email).exists():
            return render(request, "register.html", {
                "errors": {
                    "email": ["This email address is already registered. Please use another email."]
                },
                "first_name": first_name,
                "last_name": last_name,
                "email": email,
            })

        # Check passwords match
        if password != confirm_password:
            return render(request, "register.html", {
                "errors": {
                    "password": ["Passwords do not match."]
                },
                "first_name": first_name,
                "last_name": last_name,
                "email": email,
            })

        # Create the student account
        student = Student(
            first_name=first_name,
            last_name=last_name,
            email=email,
            password=make_password(password)
        )

        try:
            # Run model validation
            student.full_clean()

            # Save the student
            student.save()

            # Redirect to login after successful registration
            return redirect("login")

        except ValidationError as e:
            return render(request, "register.html", {
                "errors": e.message_dict if hasattr(e, "message_dict") else {
                    "error": e.messages
                },
                "first_name": first_name,
                "last_name": last_name,
                "email": email,
            })

    return render(request, "register.html")


def login(request):
    if request.method == "POST":
        email = request.POST.get("email", "").strip()
        password = request.POST.get("password", "")

        # Find matching email addresses, ignoring letter case
        students = Student.objects.filter(email__iexact=email)

        if not students.exists():
            return render(request, "login.html", {
                "error": "Email is not registered."
            })

        # Handle existing duplicate accounts safely
        if students.count() > 1:
            return render(request, "login.html", {
                "error": "Duplicate accounts found for this email. Please contact the administrator."
            })

        student = students.first()

        # Check password against the stored hashed password
        if check_password(password, student.password):
            # Store logged-in student details in the session
            request.session["student_id"] = student.student_id
            request.session["first_name"] = student.first_name

            # Redirect to the books page
            return redirect("books")

        # Incorrect password
        return render(request, "login.html", {
            "error": "Incorrect password. Please try again."
        })

    return render(request, "login.html")


@login_required(login_url="/login/")
def borrow_item(request, item_id):
    book = get_object_or_404(Book, Book_ID=item_id)

    # Check whether this learner has already borrowed this book
    existing_record = Record.objects.filter(
        Book_ID=book,
        Student_id=request.user.id
    ).first()

    if existing_record:
        messages.info(request, "You have already borrowed this book.")
    else:
        Record.objects.create(
            Book_ID=book,
            Student_id=request.user.id
        )
        messages.success(request, "Book borrowed successfully!")

    return redirect("books")
def books(request):
    all_books = Book.objects.all()
    return render(request, "books.html", {"books": all_books})